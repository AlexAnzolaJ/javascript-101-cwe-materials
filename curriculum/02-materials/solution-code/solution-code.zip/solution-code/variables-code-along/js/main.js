// ----------------------------------
// Part 1 - We do
// ----------------------------------

// 1. Declare a variable with the name "score". Assign it the value 3.
var score = 3;

// 2. Update the value of score. The new value should be 6.
score = 6;

// 3. Use console.log to print out the value of score.
console.log(score);

// ----------------------------------
// Part 2 - You do
// ----------------------------------

// 1. Declare a variable with the name "totalAmount". Assign it the value 0.
var totalAmount = 0;

// 2. Update the value of totalAmount. The new value should be 10.
totalAmount= 10;

// 3. Add five to the totalAmount using the += operator.
totalAmount += 5;

// 4. Use console.log to print out the value of totalAmount.
console.log(totalAmount);
